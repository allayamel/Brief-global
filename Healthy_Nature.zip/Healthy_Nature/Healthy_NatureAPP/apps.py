from django.apps import AppConfig


class HealthyNatureappConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'Healthy_NatureAPP'
